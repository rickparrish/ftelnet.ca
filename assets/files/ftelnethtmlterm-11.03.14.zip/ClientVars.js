var ClientVars = {};

// AutoConnect controls how a connection to the remote server is initiated.  
//   0 = Disabled -- User must click a button to connect
//   1 = Enabled -- Connection is made after the page loads
// Default: 0
ClientVars.AutoConnect = 0;

// BitsPerSecond controls how fast data is received from the remote server 
// (except during file transfers, which run at full speed).
//   Here are some suggested values to try:
//     115200, 57600, 38400, 28800, 19200, 14400, 9600, 4800, 2400, 1200, 300
//   (Those were just common bitrates, feel free to use any value you want)
// Default: 115200
ClientVars.BitsPerSecond = 115200;

// Blink controls whether blinking text and high intensity background colours 
// are available.
//   0 = Blinking text is disabled, high intensity background colours are 
//       enabled (this is how modern Windows OS's handle blinking text)
//   1 = Blinking text is enabled, high intensity background colours are 
//        disabled (this is how it was with DOS)
// Default: 1
ClientVars.Blink = 1;

// BorderStyle controls how the border and close button looks.
//   "FlashTerm"  = Single pixel border, like FlashTerm, no close button
//   "None"       = No border, no close button
//   "Ubuntu1004" = Ubuntu 10.04 style
//   "Win2000"    = Windows 2000 style
//   "Win7"       = Windows 7 style
//   "WinXP"      = Windows XP style
// Default: Win7
ClientVars.BorderStyle = "Win7";

// CodePage controls which font file to use.
// NOTE: Each code page has its own set of supported FondWidth and FontHeight
//       values, so see the online documentation for help selecting OK values
//   Available IBM PC code pages: 
//     437 = The original IBM PC code page
//     737 = Greek
//     850 = Multilingual (Latin-1) (Western European languages)
//     852 = Slavic (Latin-2) (Central and Eastern European languages)
//     855 = Cyrillic
//     857 =  Turkish
//     860 = Portuguese
//     861 = Icelandic
//     862 = Hebrew
//     863 = French (Quebec French)
//     865 = Danish/Norwegian
//     866 = Cyrillic
//     869 = Greek
//   Available Amiga "code pages": 
//     BStrict
//     BStruct
//     MicroKnight
//     MoSoul
//     PotNoodle
//     Topaz
//     TopazPlus
//   Available Atari "code pages" for standard 40 column displays:
//     ATASCII-Arabic
//     ATASCII-Graphics (Default for Atari)
//     ATASCII-International
//   Available Atari "code pages" for non-standard 80 column displays:
//     ATASCII-Arabic-HalfWidth
//     ATASCII-Graphics-HalfWidth
//     ATASCII-International-HalfWidth
// Default: 437
ClientVars.CodePage = "437"; 

// ConnectAnsi controls which ANSI file to display under the initial Connect button
// Default: connect.ans
ClientVars.ConnectAnsi = "connect.ans";

// Enter controls what to send to the server when the Enter key is pressed.  
//   The telnet specification says to send \r\n (ASCII CRLF) when the Enter key
//   is pressed, but not all software will work with that, so you may have more
//   luck with the non-standard \r (ASCII CR without the LF). 
// Default: \r
ClientVars.Enter = "\r";

// FontHeight and FontWidth control the size of each character on screen.  
// NOTE: These values only need to be set if you're using an IBM PC code page.
//       The Amiga and Atari code pages will override these values, as there
//       is only one available font size for those "code pages".
//   Available IBM PC code page sizes: 
//     437 = 8x12, 8x13, 9x16, 10x19, 12x23
//     737 =             9x16,        12x23
//     850 =       8x13, 9x16, 10x19, 12x23
//     852 =             9x16, 10x19, 12x23
//     855 =             9x16                 
//     857 =             9x16              
//     860 =             9x16              
//     861 =             9x16              
//     862 =                   10x19         
//     863 =             9x16                 
//     865 =       8x13, 9x16, 10x19, 12x23
//     866 =             9x16                 
//     869 =             9x16              
// Default: 9x16
ClientVars.FontWidth = 9;
ClientVars.FontHeight = 16;

// Proxy settings allow fTelnet and HtmlTerm to connect to ANY telnet server,
// regardless of whether they have the proper flash socket policy server
// installed, or if the understand the WebSocket protocol.
// NOTE: Telnet servers must first be authorized, since I can't have you
//       proxying to just any remote server (for example, I don't want my
//       proxy being used to abuse cia.gov or something!)
// For more information on using the proxy, please see the online documentation.
// These settings are commented out by default, which disables proxy use.
// ClientVars.ProxySocketPolicyPort = 843;
// ClientVars.ProxyTelnetHostName = "proxy.ftelnet.ca";
// ClientVars.ProxyTelnetPort = 2323;
// ClientVars.ProxyWebSocketHostName = "proxy.ftelnet.ca";
// ClientVars.ProxyWebSocketPort = 1123;

// ScreenColumns and ScreenRows control the size of the screen.  
//   Anything within reason should be accepted 
//   (no sanity checking is done, so bad values can/will crash the program)
// Default: 80x25 
ClientVars.ScreenColumns = 80;
ClientVars.ScreenRows = 25;

// SendOnConnect controls what text will be sent to the server immediately 
// after connecting.  Useful for auto-login purposes.  
// Default: empty
ClientVars.SendOnConnect = "";

// ServerName is the display name for the server
ClientVars.ServerName = "fTelnet and HtmlTerm Support BBS";

// SocketPolicyPort is the port that your flash socket policy server is 
// running on the remote server (required by flash, wish I could disable it!)
// For more information on setting up a flash socket policy server, please see 
// the online documentation.
// Default: 843
ClientVars.SocketPolicyPort = 843;

// TelnetHostName is the host name or IP address of the remote telnet server
// NOTE: fTelnet specific setting
ClientVars.TelnetHostName = "bbs.ftelnet.ca";

// TelnetPort is the port number to connect to on the remote telnet server
// NOTE: fTelnet specific setting
// Default: 23
ClientVars.TelnetPort = 23;

// WebSocketHostName is the host name or IP address of the remote websocket server
// NOTE: HtmlTerm specific setting
ClientVars.WebSocketHostName = "bbs.ftelnet.ca";

// WebSocketPort is the port number to connect to on the remote websocket server
// NOTE: HtmlTerm specific setting
// Default: 1123
ClientVars.WebSocketPort = 1123;